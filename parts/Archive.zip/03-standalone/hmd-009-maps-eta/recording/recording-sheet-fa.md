# برگهٔ ضبط · HMD-009 · گوگل‌مپس از کجا می‌فهمد کی می‌رسی؟

- **قاب:** 14 · **واژهٔ گفتاری:** 1666 · **گفتار:** حدود 13 دقیقه (به‌اضافهٔ زمان نمایش دک)
- **هوک:** Shock/Contradiction
- **دک:** [`deck-fa.html`](../deck-fa.html) (→ بعدی، ← قبلی، F تمام‌صفحه، H پنهان‌کردن نوار، N یادداشت راوی؛ هنگام ضبط H بزن و N خاموش باشد). قاب اول کاور است: بعد از هوک و معرفی کانال نشانش بده. نسخهٔ انگلیسی با همان ترتیب: [`deck-en.html`](../deck-en.html)
- **تله‌پرامپتر:** [`teleprompter-fa.html`](teleprompter-fa.html) (Space پخش/توقف، ↑↓ سرعت، M آینه) یا [`teleprompter-fa.txt`](teleprompter-fa.txt)

## نقشهٔ قاب‌ها

| قاب | شروع | عنوان | روی صفحه |
|---:|---|---|---|
| 1 | 00:00 | ترافیکی که هنوز نیامده | `Your ETA is a forecast of traffic that doesn't exist yet.` |
| 2 | 00:49 | یک عدد، یک تصمیم | `One number. One daily decision.` |
| 3 | 01:48 | منبع | `DeepMind × Google Maps (2020): ETA accuracy improved by up to 50% in some cities` |
| 4 | 03:05 | تاریخچه و الان | `Ingredient 1: history · Ingredient 2: live speed` |
| 5 | 04:12 | موج ترافیک | `Ingredient 3: neighbours. Traffic jams travel backwards.` |
| 6 | 05:19 | گراف و پیام | `Each road segment listens to its neighbours (message passing).` |
| 7 | 06:34 | نقشهٔ کوچک ما | `Toy city: 12 km route · 8 segments · 4 side streets · 60 synthetic workdays` |
| 8 | 07:44 | چهار پیش‌بین | `Constant · Historical · Live-now · Neighbour-aware` |
| 9 | 08:46 | نتیجه | `Mean absolute error (min): 3.43 · 1.72 · 1.13 · 0.56` |
| 10 | 10:14 | دو صبح، دو اشتباه | `07:45 jam building: live-now 18.1 vs actual 24.0 · 08:30 jam clearing: live-now 29.9 vs actual 22.6 (constant: 16.6)` |
| 11 | 11:42 | بدبینی سالم | `We built a world where neighbours matter. Of course they won.` |
| 12 | 12:44 | مرز ادعا | `THIS SHOWS / THIS DOES NOT SHOW` |
| 13 | 13:25 | جواب | `ETA = history + live + neighbours → forecast` |
| 14 | 14:13 | قسمت بعد | `A wrong ETA costs minutes. A wrong AI answer can cost more.` |

## باز پیش از ضبط

- [ ] `python3 artifact/eta_toy.py --seeds 20` اجرا شد و با `results-seed2026.json`، قاب ۹ و ۱۰ و دک یکی است: MAE 3.43/1.72/1.13/0.56؛ اوج 3.16/2.44/1.84/0.85؛ ۵۵۵ سفر، میانگین 15.8 دقیقه؛ 20/20 seed؛ مثال‌ها 07:45 (24.0؛ live 18.1؛ neighbour 20.6) و 08:30 (22.6؛ live 29.9).
- [ ] عدد «بیش از ۴۰٪ کاهش پیامدهای منفی ETA در شهرهایی مثل سیدنی» از چکیدهٔ مقالهٔ CIKM 2021 است و روی صفحه با نام مقاله می‌آید.
- [ ] هیچ نام اپ ایرانی/تاکسی اینترنتی روی صفحه یا در گفتار به‌عنوان منبع داده نیامده.
- [ ] برچسب ILLUSTRATIVE روی همهٔ قاب‌های شبیه‌سازی.
- [ ] دک: ←/→، F، H، N امتحان شد.

## دستورهای روی صفحه (از README)

```bash
python3 parts/03-standalone/hmd-009-maps-eta/artifact/eta_toy.py --seeds 20
python3 parts/03-standalone/hmd-009-maps-eta/artifact/eta_toy.py --json      # خروجی ماشینی
python3 parts/03-standalone/hmd-009-maps-eta/artifact/eta_toy.py --seed 7    # آزمون پایداری
```

## B-roll

- قاب 1 (00:00): [B-ROLL CUE] نمای داشبورد صبح در یک بزرگراه شهری (تصویر عمومی یا ضبط خودمان، بدون پلاک خوانا)؛ گوشی روی داشبورد با عدد `22 min`. بعد انیمیشن ساده: خیابان جلوی ماشین سبز، تقاطع بعدی خاکستری با برچسب `+10 min`. کات روی «من محمدم…».
- قاب 5 (04:12): [CAMERA CHANGE] کات به نمای نزدیک برای CTA. بعد [B-ROLL CUE] نمای هوایی (آرشیوی با مجوز یا انیمیشن) از صفی که از یک خروجی به عقب کش می‌آید؛ روی دک: نوارهای قرمز که هر چند ثانیه یک تکه عقب‌تر می‌روند.
- قاب 7 (06:34): [B-ROLL CUE] ضبط صفحه از باز کردن `artifact/eta_toy.py` و بالا آمدن نقشهٔ گراف روی دک. برچسب بزرگ و ثابت `ILLUSTRATIVE · synthetic traffic · not Google data · not Tehran data`. نوار زمانی ۶۰ روز: ۴۵ روز اول `TRAIN`، ۱۵ روز آخر `TEST` (کهربایی).
- قاب 13 (13:25): [B-ROLL CUE] برگشت به همان نمای داشبورد قاب ۱؛ این بار روی تصویر سه برچسب کوچک `history` `live` `neighbours`. کارت تمرین پنج‌روزه.

ساخته‌شده با `python3 scripts/export-teleprompter.py`. متن اصلی همیشه `script-fa.md` است.
