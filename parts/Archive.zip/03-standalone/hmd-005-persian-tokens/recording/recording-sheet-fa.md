# برگهٔ ضبط · HMD-005 · چرا نوشتن فارسی برای بعضی AIها توکن بیشتری می‌برد؟

- **قاب:** 14 · **واژهٔ گفتاری:** 1567 · **گفتار:** حدود 12 دقیقه (به‌اضافهٔ زمان نمایش دک)
- **هوک:** Shock/Contradiction
- **دک:** [`deck-fa.html`](../deck-fa.html) (→ بعدی، ← قبلی، F تمام‌صفحه، H پنهان‌کردن نوار، N یادداشت راوی؛ هنگام ضبط H بزن و N خاموش باشد). قاب اول کاور است: بعد از هوک و معرفی کانال نشانش بده. نسخهٔ انگلیسی با همان ترتیب: [`deck-en.html`](../deck-en.html)
- **تله‌پرامپتر:** [`teleprompter-fa.html`](teleprompter-fa.html) (Space پخش/توقف، ↑↓ سرعت، M آینه) یا [`teleprompter-fa.txt`](teleprompter-fa.txt)

## نقشهٔ قاب‌ها

| قاب | شروع | عنوان | روی صفحه |
|---:|---|---|---|
| 1 | 00:00 | کوتاه‌تر می‌نویسیم، بلندتر حساب می‌شود | `Fewer letters. More tokens.` |
| 2 | 00:45 | چرا به تو مربوط است | `What you pay for is not letters. It is tokens.` |
| 3 | 01:45 | توکن چیست؟ اول انگلیسی | `I want to cancel my subscription… = 15 tokens` |
| 4 | 02:40 | همان جمله به فارسی | `Same sentence in Persian: 22 · 46 · 69 tokens` |
| 5 | 03:35 | چرا؟ منبع اصلی | `Tokenizers are trained on text. Not all languages get equal room.` |
| 6 | 04:35 | آزمایش: ۵۰ جفت، ۹ tokenizer | `50 pairs · 7 domains · 9 tokenizers · ratio = fa ÷ en` |
| 7 | 05:35 | جدول نتیجه | `Median Persian/English token ratio: 1.21× → 4.61×` |
| 8 | 06:40 | یک عدد کافی نیست | `o200k_base: half of the pairs fall between 1.23× and 1.50×` |
| 9 | 07:45 | هوک دوم: کیبورد خودت | `ی vs ي · ک vs ك — same look, different tokens` |
| 10 | 08:50 | نیم‌فاصله و رقم‌ها | `ZWNJ: free on most · costly on one. Digits: depends.` |
| 11 | 09:55 | هزینه و حافظه، فقط با فرمول | `cost_fa ≈ ratio × cost_en   (same text, same price list)` |
| 12 | 10:55 | مرز ادعا | `THIS SHOWS / THIS DOES NOT SHOW` |
| 13 | 11:45 | جواب | `Your text. Your tokenizer. Count it.` |
| 14 | 12:30 | قسمت بعد | `Next: "fewer errors" — out of what?` |

## باز پیش از ضبط

- [ ] اجرای دوبارهٔ `count_tokens.py --offline` و تطبیق با `results-2026-11-02.md`.
- [ ] خوانش آزمایشی و تنظیم زمان قاب‌ها و `data-start` دک.
- [ ] `python3 artifact/count_tokens.py --offline` را دوباره اجرا کن و مطمئن شو جدول با `artifact/results-2026-11-02.md` یکی است (نسخه‌ها pin شده‌اند).
- [ ] اگر روز ضبط اسکریپت را با تاریخ تازه اجرا کردی و عددی فرق کرد، عدد گفتار و دک را از فایل تازه بردار، نه از این متن.
- [ ] نسبت‌دادن tokenizer به مدل فقط از نقشهٔ داخل tiktoken 0.9.0 است؛ دربارهٔ محصول امروز ادعا نکن.
- [ ] عبارت «اولین پژوهش» یا «فقط ما» در هیچ‌جا نیست.
- [ ] واژهٔ «بی‌انصافی» فقط به عنوان مقالهٔ R14 نسبت داده شود، نه حکم ما.
- [ ] دک: کلیدها، F، H و N؛ تعداد قاب‌ها ۱۴.

## دستورهای روی صفحه (از README)

```bash
python3 -m pip install tiktoken==0.9.0 transformers==4.49.0   # transformers اختیاری است
python3 parts/03-standalone/hmd-005-persian-tokens/artifact/count_tokens.py            # دانلود tokenizerها در اولین اجرا
python3 parts/03-standalone/hmd-005-persian-tokens/artifact/count_tokens.py --offline  # فقط کش محلی
python3 parts/03-standalone/hmd-005-persian-tokens/artifact/count_tokens.py --only o200k_base cl100k_base
```

## B-roll

- قاب 1 (00:00): [B-ROLL CUE] صفحهٔ چت؛ یک پیام فارسی و همان پیام به انگلیسی کنار هم. شمارندهٔ حرف زیر هر کدام؛ بعد شمارندهٔ توکن با رنگ کهربایی ظاهر می‌شود. قاب night.
- قاب 6 (04:35): [B-ROLL CUE] ضبط صفحه: باز کردن `artifact/corpus/pairs.jsonl` و اجرای `python3 artifact/count_tokens.py`. نام نُه tokenizer یکی‌یکی تیک می‌خورد.

ساخته‌شده با `python3 scripts/export-teleprompter.py`. متن اصلی همیشه `script-fa.md` است.
