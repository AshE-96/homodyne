# برگهٔ ضبط · HMD-003 · می‌شود آتش جنگل را وقتی هنوز کوچک است پیدا کرد؟

- **قاب:** 15 · **واژهٔ گفتاری:** 1635 · **گفتار:** حدود 13 دقیقه (به‌اضافهٔ زمان نمایش دک)
- **هوک:** شمارهٔ ۳، Story-Open
- **دک:** [`deck-fa.html`](../deck-fa.html) (→ بعدی، ← قبلی، F تمام‌صفحه، H پنهان‌کردن نوار، N یادداشت راوی؛ هنگام ضبط H بزن و N خاموش باشد). قاب اول کاور است: بعد از هوک و معرفی کانال نشانش بده. نسخهٔ انگلیسی با همان ترتیب: [`deck-en.html`](../deck-en.html)
- **تله‌پرامپتر:** [`teleprompter-fa.html`](teleprompter-fa.html) (Space پخش/توقف، ↑↓ سرعت، M آینه) یا [`teleprompter-fa.txt`](teleprompter-fa.txt)

## نقشهٔ قاب‌ها

| قاب | شروع | عنوان | روی صفحه |
|---:|---|---|---|
| 1 | 00:00 | آبان پارسال، جنگل الیت | `Elit forest, Mazandaran · November 2025` |
| 2 | 00:43 | یک نقطهٔ داغ | `One hot dot. Fire? Factory? Sensor glitch?` |
| 3 | 01:46 | ماهواره شعله نمی‌بیند، گرما می‌بیند | `One VIIRS pixel ≈ 375 m × 375 m ≈ 14 ha` |
| 4 | 02:49 | یک سطر از دادهٔ ناسا | `NASA FIRMS · free hot-spot data · one row` |
| 5 | 03:56 | اولین نقطه، آتش نیست | `python3 artifact/firms_timeline.py --demo` |
| 6 | 04:50 | دودکش سر جایش می‌ماند | `Same spot, 5 nights in a row → probably not a spreading fire` |
| 7 | 05:53 | سخت‌گیر باشیم یا حساس؟ | `kept if threshold were:  low → 18 · nominal → 15 · high → 7` |
| 8 | 06:54 | دادهٔ واقعی: الیت، و عددهایی که با هم نمی‌خوانند | `Elit fire, Aban 1404: official burned-area estimates range from ~8 ha to 150–180 ha` |
| 9 | 07:59 | ولی یک جای این نقشه می‌لنگد | `No ground truth → no precision, no recall` |
| 10 | 08:58 | پیشرفت بی‌سروصدا: FireSat | `FireSat · first operational fire images · 16 Sep 2026` |
| 11 | 10:00 | هوش مصنوعی همان سؤال ما را می‌پرسد | `Compare each 5 × 5 m spot with its past · nearby infrastructure · local weather` |
| 12 | 11:00 | بیست دقیقه، هدف است نه امروز | `2026 ≥2×/day to early adopters · 2028 global access · 2029 hourly · early 2030s every 20 min` |
| 13 | 11:53 | این قسمت چه چیزی را ثابت نمی‌کند | `THIS SHOWS / THIS DOES NOT SHOW` |
| 14 | 12:38 | جواب | `A hot spot is a lead, not a verdict.` |
| 15 | 13:25 | قسمت بعد | `Next · Is the #1 model on the leaderboard #1 for you?` |

## باز پیش از ضبط

- [ ] (اختیاری) MAP_KEY رایگان FIRMS (راهنما در `artifact/README.md`) و اجرای
- [ ] فیلم/عکس آرشیوی آتش الیت فقط با مجوز، تاریخ و منبع؛ تصاویر FireSat فقط از صفحهٔ رسمی EFA.
- [ ] `python3 parts/03-standalone/hmd-003-wildfire-from-space/artifact/firms_timeline.py --demo` و `--demo --min-confidence low --quiet` اجرا و با قاب ۵ و ۷ دک تطبیق شود (۲ نوامبر ۲۰۲۶ تطبیق داده شد).
- [ ] `python3 scripts/check-season-01.py` بدون خطا برای HMD-003.
- [ ] (اختیاری) اگر کلید رایگان FIRMS رسید: `FIRMS_MAP_KEY=… python3 artifact/firms_timeline.py --fetch --region elit --start 2025-10-28 --end 2025-11-27 --save data/elit_2025-11.csv` و متن جایگزین زیر قاب ۸. وگرنه قاب ۸ همان‌طور که هست ضبط شود.
- [ ] (اختیاری) اگر `*_SP` برای نوامبر ۲۰۲۵ داده نداد، `*_NRT` یا Archive Download.
- [ ] اگر فهرست محل‌های صنعتی واقعی ساختی، منبع هر سطر (OpenStreetMap یا نقشهٔ رسمی) کنار آن ثبت شود؛ نام تأسیسات واقعی بدون شاهد «منبع کاذب» خوانده نشود.
- [ ] تصاویر FireSat فقط از صفحهٔ رسمی EFA با ذکر منبع؛ هیچ‌جا نقشهٔ FIRMS «FireSat» نامیده نشود.
- [ ] عبارت «قبل از اینکه کسی متوجه شود» و معادل‌هایش در متن، توضیحات و Shortها نیامده باشد.
- [ ] `python3 parts/03-standalone/hmd-003-wildfire-from-space/artifact/firms_timeline.py --demo` اجرا و با قاب ۵ و ۷ دک تطبیق شود.

## B-roll

- قاب 1 (00:00): قاب night. [B-ROLL CUE] فیلم آرشیوی مجوزدار و تاریخ‌دار از آتش الیت (آبان ۱۴۰۴)، با زیرنویس منبع و تاریخ؛ بدون تصویر بی‌تاریخ. بعد کات به نقشهٔ تیرهٔ شمال ایران. نمایش +3s
- قاب 6 (04:50): [B-ROLL CUE] تصویر عمومی و بی‌نام از دودکش صنعتی در شب (نه یک تأسیسات واقعی شناسایی‌پذیر در ایران)؛ بعد نقشه با پنج نقطهٔ روی‌هم‌افتاده کنار SITE-A و نقطه‌های پراکندهٔ آتش که جابه‌جا می‌شوند. نمایش +4s
- قاب 10 (08:58): [B-ROLL CUE] فقط تصاویر رسمی منتشرشده در صفحهٔ Earth Fire Alliance (با ذکر منبع و تاریخ، طبق شرایط استفاده)؛ جدا از نقشهٔ FIRMS ما، با قاب و رنگ متفاوت. کارت منبع: `Earth Fire Alliance & Muon Space · 16 Sep 2026`. نمایش +5s

ساخته‌شده با `python3 scripts/export-teleprompter.py`. متن اصلی همیشه `script-fa.md` است.
