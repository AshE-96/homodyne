# برگهٔ ضبط · HMD-016 · کدام AI به‌موقع می‌گوید «نمی‌دانم»؟ نتیجهٔ آزمون ما

- **قاب:** 15 · **واژهٔ گفتاری:** 1704 · **گفتار:** حدود 13 دقیقه (به‌اضافهٔ زمان نمایش دک)
- **هوک:** Story-Open «کتاب سوم»
- **دک:** [`deck-fa.html`](../deck-fa.html) (→ بعدی، ← قبلی، F تمام‌صفحه، H پنهان‌کردن نوار، N یادداشت راوی؛ هنگام ضبط H بزن و N خاموش باشد). قاب اول کاور است: بعد از هوک و معرفی کانال نشانش بده. نسخهٔ انگلیسی با همان ترتیب: [`deck-en.html`](../deck-en.html)
- **تله‌پرامپتر:** [`teleprompter-fa.html`](teleprompter-fa.html) (Space پخش/توقف، ↑↓ سرعت، M آینه) یا [`teleprompter-fa.txt`](teleprompter-fa.txt)

## نقشهٔ قاب‌ها

| قاب | شروع | عنوان | روی صفحه |
|---:|---|---|---|
| 1 | 00:00 | کتاب سوم | `"When was her third book translated?" She only wrote two.` |
| 2 | 00:50 | «به‌موقع» دو نیمه دارد | `Coverage: how often it answers · Risk: how often its answers are wrong` |
| 3 | 01:55 | ایدهٔ قدیمی، مسئلهٔ حل‌نشده | `AbstentionBench (2025): 20 datasets · 20 models · abstention "unsolved"` |
| 4 | 02:59 | قانون امتیاز و خط صفر | `Right +1 · "I don't know" 0 · Wrong −3 · Always silent = 0` |
| 5 | 03:55 | من داورم | `Written before the run: primary rule · primary metric · ONE confirmatory comparison` |
| 6 | 05:06 | یک برچسب، هشی دیگر | `One label changed in 1,050 rows → a completely different SHA-256` |
| 7 | 06:12 | سه مدل خیالی، یک جدول | `ILLUSTRATIVE · A: covers 96%, risk 34%, −0.33 · B: 67%, 17%, +0.20 · C: 52%, 7%, +0.38` |
| 8 | 07:21 | اختلاف جفتی و بازه | `CONFIRMATORY · B − A, question by question: +0.53 [+0.33, +0.74] · ILLUSTRATIVE` |
| 9 | 08:37 | تلهٔ پانزده مقایسه | `6 models → 15 pairs → P(at least one false alarm) ≈ 54% (if independent, no real difference)` |
| 10 | 09:48 | صفر از پنجاه | `Unanswerable questions · ILLUSTRATIVE · A: 37/50 made up → BREACH · C: 0/50 → still UNKNOWN` |
| 11 | 10:47 | [RUN] جدول واقعی | `[RUN] NOT RUN YET · Locked Bluff data · t75 · coverage · risk · score` |
| 12 | 11:46 | [RUN] مقایسهٔ ثبت‌شده | `[RUN] NOT RUN YET · CONFIRMATORY pair (preregistered) · paired difference + 95% CI` |
| 13 | 12:31 | مرز ادعا | `THIS SHOWS / THIS DOES NOT SHOW` |
| 14 | 13:11 | جواب | `On time = high coverage AND low risk, under a rule that prices your mistakes.` |
| 15 | 13:55 | قسمت بعد | `Why did YouTube recommend this video to you?` |

## باز پیش از ضبط

- [ ] [RUN] قفل دادهٔ Bluff: manifest پاسخ‌ها، داوری نهایی، طرح تحلیل ثبت‌شده (شرط اصلی، مقایسهٔ تأییدی، حد عملی، سقف ساختن جواب) و هش‌ها منتشر شده باشند. تا آن موقع قاب ۱۱ و ۱۲ ضبط نشوند.
- [ ] [RUN] پس از قفل: `abstain_report.py <locked.csv> --plan <plan.json>` اجرا، جای‌خالی‌های کروشه‌ای قاب ۱۱ و ۱۲ پر و فقط یک شاخه نگه داشته شد؛ دک beat-11 و beat-12 به‌روز شد.
- [ ] هیچ عدد آموزشی به مدل واقعی نسبت داده نشده؛ نام مدل‌های واقعی فقط در قاب ۱۱ و ۱۲ و فقط از دادهٔ قفل‌شده.
- [ ] دک: ←/→، F، H، N امتحان شد.

## دستورهای روی صفحه (از README)

```bash
python3 parts/02-benchmarking/e08-which-model-knows-when-to-abstain/artifact/abstain_report.py --selftest
python3 parts/02-benchmarking/e08-which-model-knows-when-to-abstain/artifact/abstain_report.py --demo        # عددهای قاب ۶ تا ۱۰
# پس از قفل داده [RUN]:
python3 parts/02-benchmarking/e08-which-model-knows-when-to-abstain/artifact/abstain_report.py locked.csv --plan plan.json
```

## B-roll

- قاب 1 (00:00): [B-ROLL CUE] صحنهٔ بازسازی‌شده: لپ‌تاپ در اتاق نیمه‌تاریک، ساعت گوشهٔ صفحه 23:04؛ سؤال تایپ می‌شود و جوابی بی‌مکث با سال، مترجم و ناشر ظاهر می‌شود. رابط کاربری عمومی و بی‌نام؛ نویسنده و کتاب خیالی؛ برچسب کوچک `RECONSTRUCTED SCENE · not a recorded model answer`. کات روی «من محمدم…».
- قاب 6 (05:06): [B-ROLL CUE] ضبط ترمینال: `python3 artifact/abstain_report.py --demo`؛ [SOUND EFFECT] «تیک» نرم هنگام ظاهر شدن هش دوم؛ اول سطر `input sha256 a39e3469…`، بعد سطر `Tamper test … 2ce360be…`؛ چهار حرف اول هر دو کهربایی. برچسب ثابت `ILLUSTRATIVE · fictional models, fictional questions, no model was called`.
- قاب 10 (09:48): [B-ROLL CUE] برگشت کوتاه به صحنهٔ «کتاب سوم» قاب ۱؛ [GRAPHIC] بعد بخش ۲ خروجی: سه ردیف با بازهٔ Wilson؛ ردیف C (`0/50 · CI [0%, 7%] vs 5% → UNKNOWN`) کهربایی. زیرنویس `5% = our design choice, not a safety standard`.
- قاب 15 (13:55): [SOUND EFFECT] صدای کوتاه کلیک؛ [B-ROLL CUE] ستون ویدیوهای پیشنهادی کنار پخش‌کننده (ماکت عمومی، بدون اسم کانال واقعی). End screen به HMD-017.

ساخته‌شده با `python3 scripts/export-teleprompter.py`. متن اصلی همیشه `script-fa.md` است.
