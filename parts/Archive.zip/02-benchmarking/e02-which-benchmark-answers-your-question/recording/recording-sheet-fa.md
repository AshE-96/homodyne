# برگهٔ ضبط · HMD-004 · مدل اول جدول، برای تو هم بهترین است؟

- **قاب:** 14 · **واژهٔ گفتاری:** 1554 · **گفتار:** حدود 12 دقیقه (به‌اضافهٔ زمان نمایش دک)
- **هوک:** Curiosity-Gap
- **دک:** [`deck-fa.html`](../deck-fa.html) (→ بعدی، ← قبلی، F تمام‌صفحه، H پنهان‌کردن نوار، N یادداشت راوی؛ هنگام ضبط H بزن و N خاموش باشد). قاب اول کاور است: بعد از هوک و معرفی کانال نشانش بده. نسخهٔ انگلیسی با همان ترتیب: [`deck-en.html`](../deck-en.html)
- **تله‌پرامپتر:** [`teleprompter-fa.html`](teleprompter-fa.html) (Space پخش/توقف، ↑↓ سرعت، M آینه) یا [`teleprompter-fa.txt`](teleprompter-fa.txt)

## نقشهٔ قاب‌ها

| قاب | شروع | عنوان | روی صفحه |
|---:|---|---|---|
| 1 | 00:00 | ششم بود؛ بعد؟ | `Rank 6 → ?  Same votes. One thing removed.` |
| 2 | 00:41 | قهرمان آشپزی، مدیر رستوران؟ | `Answer a fact · Summarise a document · Change a booking` |
| 3 | 01:36 | جدول رأی دقیقاً چه چیزی را می‌شمارد؟ | `Style control: GPT-4o-mini 6 → 11 · Claude 3 Opus 16 → 10` |
| 4 | 02:50 | کارنامه، نه رتبه | `A model has a profile, not a rank.` |
| 5 | 03:57 | زنجیره: از خطا شروع کن | `Decision → Costly failure → Required evidence → Family` |
| 6 | 04:50 | ابزار خودم پیشنهاد اشتباه داد | `m2bench families --decision "customer support bot…" --failure "…wrong refund policy"` |
| 7 | 05:44 | همان نیاز، کلمه‌های دیگر | `Same need. Different words. Different family.` |
| 8 | 06:43 | نقشه و نقطه‌های کور | `Capability · System · Trust · Value — learn the blind spots, not the names` |
| 9 | 08:01 | ولی این آزمون هنوز زنده است؟ | `SWE-bench Verified · 138 audited · ≥ 59.4% flawed tests · Feb 2026` |
| 10 | 08:57 | جانشین هم ممیزی می‌خواهد | `Feb 2026: drop Verified, adopt Pro → Jul 2026: Pro recommendation retracted` |
| 11 | 10:03 | یک آزمون را در پنج سؤال باز کن | `SimpleQA: Claim · Task · Metric · Blind spot · Life` |
| 12 | 10:57 | این قسمت چه چیزی را ثابت نمی‌کند | `THIS SHOWS / THIS DOES NOT SHOW` |
| 13 | 11:34 | جواب | `Task · Costly failure · Evidence · Test` |
| 14 | 12:18 | قسمت بعد | `Next · Same sentence, English vs Persian: count the pieces.` |

## باز پیش از ضبط

- [ ] اجرای دوبارهٔ دو دستور قاب ۶ و ۷ (در `artifact/decision-card.md`) از ریشهٔ مخزن و تطبیق با دک؛ اگر `framework/00-landscape/benchmark-families.yaml` تغییر کرده، خروجی جدید را در دک بگذار.
- [ ] عددهای Arena همیشه با «آگوست ۲۰۲۴» و «در آن تحلیل».
- [ ] SWE-bench: «دست‌کم ۵۹٫۴٪ از ۱۳۸ مسئلهٔ بازبینی‌شده؛ نمونهٔ تصادفی کل نبود»؛ Pro: «حدود ۳۰٪، برآورد خود OpenAI، ۸ ژوئیهٔ ۲۰۲۶».
- [ ] صفحهٔ R03 و R04 یک بار دستی در مرورگر دیده شود (ابزار خودکار 403 گرفت؛ عددها از جست‌وجو و منابع ثانویه تأیید شدند).
- [ ] برچسب ILLUSTRATIVE روی قاب ۳، ۴ و ۱۴.
- [ ] `python3 scripts/check-season-01.py` بدون خطا برای HMD-004.
- [ ] دو دستور قاب ۶ و ۷ از ریشهٔ مخزن اجرا و با دک تطبیق شوند (۲ نوامبر ۲۰۲۶ تطبیق داده شد):
- [ ] عددهای Arena فقط با تاریخ آگوست ۲۰۲۴ و عبارت «در آن تحلیل»؛ رتبه‌های امروز نیستند.
- [ ] SWE-bench Verified: «دست‌کم ۵۹٫۴٪ از ۱۳۸ مسئلهٔ بازبینی‌شده» + «نمونهٔ تصادفی کل مجموعه نبود».
- [ ] SWE-bench Pro: «حدود ۳۰٪ برآورد خود OpenAI» و تاریخ ۸ ژوئیهٔ ۲۰۲۶؛ هیچ جانشین «تأییدشده‌ای» معرفی نشود.
- [ ] مدل‌های X و Y و دو پاسخ قاب ۳ ILLUSTRATIVE.
- [ ] هیچ جمله‌ای دربارهٔ اجرای Bluff به‌صورت انجام‌شده.
- [ ] دک: ← → ، F، H، N امتحان شوند.

## B-roll

- قاب 1 (00:00): قاب night. [B-ROLL CUE] یک ستون رتبهٔ ساده؛ ردیف ۶ کهربایی می‌شود و با انیمیشن پایین می‌لغزد، ولی عدد مقصد پشت یک علامت سؤال پنهان می‌ماند. زیرنویس منبع و تاریخ: `LMSYS · Aug 2024`. جواب در قاب ۳ (01:36). نمایش +3s
- قاب 10 (08:57): [B-ROLL CUE] دو کارت تاریخ‌دار کنار هم (R03 و R04)؛ زیرشان شش وضعیت عمر به‌صورت چیپ: `fresh · discriminating · saturating · saturated · compromised · retired` بدون پیکان اجباری؛ برچسب `as of 2026-09-29 · re-check`. نمایش +5s
- قاب 14 (12:18): [B-ROLL CUE] یک جملهٔ فارسی که به تکه‌های رنگی (توکن) شکسته می‌شود، کنار همان جمله به انگلیسی. عدد نشان داده نمی‌شود. End screen از ثانیهٔ ۱۰. نمایش +2s

ساخته‌شده با `python3 scripts/export-teleprompter.py`. متن اصلی همیشه `script-fa.md` است.
