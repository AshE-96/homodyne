# برگهٔ ضبط · HMD-002 · چطور با همان جواب‌ها، برندهٔ AI عوض می‌شود؟

- **قاب:** 14 · **واژهٔ گفتاری:** 1478 · **گفتار:** حدود 11 دقیقه (به‌اضافهٔ زمان نمایش دک)
- **هوک:** شمارهٔ ۱، Shock/Contradiction
- **دک:** [`deck-fa.html`](../deck-fa.html) (→ بعدی، ← قبلی، F تمام‌صفحه، H پنهان‌کردن نوار، N یادداشت راوی؛ هنگام ضبط H بزن و N خاموش باشد). قاب اول کاور است: بعد از هوک و معرفی کانال نشانش بده. نسخهٔ انگلیسی با همان ترتیب: [`deck-en.html`](../deck-en.html)
- **تله‌پرامپتر:** [`teleprompter-fa.html`](teleprompter-fa.html) (Space پخش/توقف، ↑↓ سرعت، M آینه) یا [`teleprompter-fa.txt`](teleprompter-fa.txt)

## نقشهٔ قاب‌ها

| قاب | شروع | عنوان | روی صفحه |
|---:|---|---|---|
| 1 | 00:00 | سه از چهار غلط، ولی برنده | `3 of 4 answers wrong. Still the winner.` |
| 2 | 00:44 | نمره را کی می‌سازد؟ | `Right · Wrong · "Let me check"` |
| 3 | 01:42 | حدس بزن کدام را استخدام می‌کنی | `A: 60 correct · B: 50 correct` |
| 4 | 02:44 | قیمت یک جواب غلط | `score = correct − k × wrong   ("I don't know" = 0)` |
| 5 | 03:47 | خودت اجرا کن | `python3 tools/bluff_lab.py demo` |
| 6 | 05:02 | جدول واقعی OpenAI | `SimpleQA · gpt-5-thinking-mini 52 / 22 / 26 · OpenAI o4-mini 1 / 24 / 75` |
| 7 | 06:07 | چرا حدس‌زدن جایزه می‌گیرد | `9 of 10 popular evals: no credit for "I don't know"` |
| 8 | 07:06 | قانون کنکور روی جدول واقعی | `Konkur rule: 3 wrong cancel 1 right  →  k = 1/3` |
| 9 | 08:09 | ولی یک جای این حساب می‌لنگد | `Rescoring ≠ re-running` |
| 10 | 09:06 | منفی یک‌سوم کنکور از کجا آمده؟ | `k = t / (1 − t)   ·   t = 0.25 → k = 1/3` |
| 11 | 10:14 | شناسنامهٔ یک نمره | `Decision · Task · Data · Run · Score · Boundary` |
| 12 | 11:02 | این قسمت چه چیزی را ثابت نمی‌کند | `THIS SHOWS / THIS DOES NOT SHOW` |
| 13 | 11:42 | جواب | `Better — under which rule?` |
| 14 | 12:25 | قسمت بعد: یک نقطهٔ داغ از فضا | `Next · One hot dot from space. Fire — or not?` |

## باز پیش از ضبط

- [ ] اجرای دوبارهٔ `python3 parts/02-benchmarking/e01-is-a-higher-score-better/artifact/two_scores.py` و `python3 tools/bluff_lab.py demo` از ریشهٔ مخزن و تطبیق با قاب ۵ و ۸ دک.
- [ ] جدول SimpleQA با تاریخ ۵ سپتامبر ۲۰۲۵ و برچسب «historical» روی صفحه.
- [ ] برچسب ILLUSTRATIVE روی همهٔ قاب‌های A/B.
- [ ] هیچ جمله‌ای دربارهٔ اجرای Bluff به‌صورت انجام‌شده.
- [ ] `python3 scripts/check-season-01.py` بدون خطا برای HMD-002.
- [ ] `python3 parts/02-benchmarking/e01-is-a-higher-score-better/artifact/two_scores.py` و `python3 tools/bluff_lab.py demo` از ریشهٔ مخزن اجرا و با قاب ۵ و ۸ دک مقایسه شوند (۲ نوامبر ۲۰۲۶ تطبیق داده شد).
- [ ] جدول SimpleQA با تاریخ «۵ سپتامبر ۲۰۲۵» و نام دقیق دو مدل روی صفحه؛ گفته شود «رتبهٔ امروز نیست».
- [ ] عبارت «۹ از ۱۰» با Table 2 مقاله (arXiv 2509.04664) تطبیق شده؛ WildBench تنها مورد «partial» است.
- [ ] هیچ جمله‌ای نگوید Bluff اجرا شده یا نتیجه دارد.
- [ ] داده‌های A و B همه‌جا `ILLUSTRATIVE`.
- [ ] دک: ← → ، F، H، N امتحان شوند؛ یادداشت راوی هنگام ضبط صفحه خاموش.
- [ ] خوانش آزمایشی؛ زمان‌های نقشه پس از ضبط بازتنظیم شوند (chapterها در `package-fa.md`).

## B-roll

- قاب 1 (00:00): قاب night. فقط ستون Accuracy دیده می‌شود: `24%` در برابر `22%`. ردیف Error هنوز پوشیده است. [B-ROLL CUE] زوم سریع روی عدد ۲۴. بدون موسیقی تا پایان جملهٔ اول. نمایش +3s
- قاب 14 (12:25): [B-ROLL CUE] تصویر آرشیوی تاریخ‌دار از جنگل‌های هیرکانی، بعد یک نقطهٔ کهربایی روی نقشهٔ تیره. End screen از ثانیهٔ ۱۰ این قاب. نمایش +2s

ساخته‌شده با `python3 scripts/export-teleprompter.py`. متن اصلی همیشه `script-fa.md` است.
