# برگهٔ ضبط · HMD-008 · اگر جواب‌نامه غلط باشد، کدام AI می‌بازد؟

- **قاب:** 14 · **واژهٔ گفتاری:** 1718 · **گفتار:** حدود 13 دقیقه (به‌اضافهٔ زمان نمایش دک)
- **هوک:** Shock/Contradiction
- **دک:** [`deck-fa.html`](../deck-fa.html) (→ بعدی، ← قبلی، F تمام‌صفحه، H پنهان‌کردن نوار، N یادداشت راوی؛ هنگام ضبط H بزن و N خاموش باشد). قاب اول کاور است: بعد از هوک و معرفی کانال نشانش بده. نسخهٔ انگلیسی با همان ترتیب: [`deck-en.html`](../deck-en.html)
- **تله‌پرامپتر:** [`teleprompter-fa.html`](teleprompter-fa.html) (Space پخش/توقف، ↑↓ سرعت، M آینه) یا [`teleprompter-fa.txt`](teleprompter-fa.txt)

## نقشهٔ قاب‌ها

| قاب | شروع | عنوان | روی صفحه |
|---:|---|---|---|
| 1 | 00:00 | بلدتر باخت | `Same 100 questions. The model that knew more lost.` |
| 2 | 00:47 | کلید اولیه | `Preliminary key → Objections → Final key` |
| 3 | 01:59 | چقدر خطا؟ | `MMLU: ~6.49% of questions estimated to contain errors` |
| 4 | 03:17 | قانون اول | `A wrong key only takes points from those who answered right.` |
| 5 | 04:30 | بدتر از نویز | `Random error blurs. A popular myth picks a winner.` |
| 6 | 05:36 | اجرا کن | `python3 artifact/key_audit_demo.py` |
| 7 | 07:11 | شاهد واقعی | `Corrected labels: ResNet-18 beats ResNet-50 if mislabeled share rises by just 6%` |
| 8 | 08:06 | خطا از کجا می‌آید؟ | `Myth · Date · Alias · Translation` |
| 9 | 09:24 | مخرج | `Suspicious-only audit: 8/36 = 22% · Random audit: 3/30 (95% CI 3%–26%) · Truth: 8%` |
| 10 | 10:52 | داوری | `Two blind reviewers · Disagreement → primary source → logged reason` |
| 11 | 11:59 | پایلوت ما | `Bluff pilot key audit: NOT RUN YET · SimpleQA Verified: 1,000 rebuilt prompts` |
| 12 | 13:08 | مرز ادعا | `THIS SHOWS / THIS DOES NOT SHOW` |
| 13 | 13:54 | جواب | `Was the key audited? Out of how many? Which version?` |
| 14 | 14:43 | قسمت بعد | `What if reality wrote the answer key?` |

## باز پیش از ضبط

- [ ] `python3 artifact/key_audit_demo.py --write-csv` اجرا و خروجی با قاب ۶، ۹ و ۱۰ و دک تطبیق داده شد (K 73/80، P 80/76، typo 73/74، 8/36، 3/30، 3%–26%).
- [ ] `python3 tools/bluff_lab.py score artifact/key-v1.csv --condition plain` و `key-v2.csv` همان accuracy را می‌دهند (0.73/0.80 و 0.80/0.76).
- [ ] عددهای منبع با `sources.md` (تاریخ بازبینی ۲ نوامبر ۲۰۲۶) یکی است: 57 موضوع و 5,700 سؤال بازخوانی‌شده، 6.49٪، 57٪ (Virology، سؤال‌های تحلیل‌شده)، ≥3.3٪، ≥6٪ ImageNet، ResNet-18/50 با «۶٪»، 28٪ و 84.9٪، 1,000 پرسش.
- [ ] برچسب ILLUSTRATIVE در همهٔ قاب‌های دادهٔ ساختگی دیده می‌شود.
- [ ] دک: ←/→، F، H، N امتحان شد؛ یادداشت راوی هنگام ضبط خاموش است.

## دستورهای روی صفحه (از README)

```bash
python3 parts/02-benchmarking/e04-who-decides-the-right-answer/artifact/key_audit_demo.py --write-csv
python3 tools/bluff_lab.py score parts/02-benchmarking/e04-who-decides-the-right-answer/artifact/key-v1.csv --condition plain
python3 tools/bluff_lab.py score parts/02-benchmarking/e04-who-decides-the-right-answer/artifact/key-v2.csv --condition plain
```

## B-roll

- قاب 2 (00:47): [B-ROLL CUE] نمای نزدیک یک پاسخ‌برگ چهارگزینه‌ای و انگشتی که روی کلید پایین می‌آید (بازسازی‌شده، بدون لوگو یا سند واقعی سازمان سنجش). بعد سه کارت مراحل روی دک.
- قاب 8 (08:06): [B-ROLL CUE] چهار کارت، هر کدام با یک مثال: `Sydney vs Canberra` · `Astana → Nur-Sultan (2019) → Astana (2022)` · `Brasília = Brasilia` · `translation adds a clue`. کارت چهارم کهربایی با پانویس `Global-MMLU: 28% culturally sensitive · 84.9% of geography Qs on N. America/Europe`.
- قاب 11 (11:59): [B-ROLL CUE] کارت `NOT RUN YET` برای ممیزی پایلوت. سپس کارت منبع SimpleQA Verified (arXiv 2509.07968، نسخهٔ دوم مارس ۲۰۲۶) با سه برچسب: `incorrect labels · topical bias · redundancy`.
- قاب 14 (14:43): [SOUND EFFECT] صدای بوق کوتاه ماشین؛ [B-ROLL CUE] نمای بزرگراه شب‌هنگام و صفحهٔ یک اپ مسیریاب با عدد ETA (تصویر عمومی، بدون ادعای داده). End screen به HMD-009.

ساخته‌شده با `python3 scripts/export-teleprompter.py`. متن اصلی همیشه `script-fa.md` است.
