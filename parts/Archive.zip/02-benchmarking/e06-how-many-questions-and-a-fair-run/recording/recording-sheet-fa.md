# برگهٔ ضبط · HMD-012 · هزار بار امتحان کردیم؛ حالا می‌شود اعتماد کرد؟

- **قاب:** 15 · **واژهٔ گفتاری:** 1619 · **گفتار:** حدود 12 دقیقه (به‌اضافهٔ زمان نمایش دک)
- **هوک:** Curiosity-Gap «دو جدول»
- **دک:** [`deck-fa.html`](../deck-fa.html) (→ بعدی، ← قبلی، F تمام‌صفحه، H پنهان‌کردن نوار، N یادداشت راوی؛ هنگام ضبط H بزن و N خاموش باشد). قاب اول کاور است: بعد از هوک و معرفی کانال نشانش بده. نسخهٔ انگلیسی با همان ترتیب: [`deck-en.html`](../deck-en.html)
- **تله‌پرامپتر:** [`teleprompter-fa.html`](teleprompter-fa.html) (Space پخش/توقف، ↑↓ سرعت، M آینه) یا [`teleprompter-fa.txt`](teleprompter-fa.txt)

## نقشهٔ قاب‌ها

| قاب | شروع | عنوان | روی صفحه |
|---:|---|---|---|
| 1 | 00:00 | دو جدول | `Two tables. 1,000 rows each. "A beats B by 3 points." Only one is evidence.` |
| 2 | 00:52 | هفتاد درصد احتمال باران | `"70% chance of rain" ↔ "3 points better ± ?"  ·  Table 1: 1,000 questions × 1  ·  Table 2: 50 questions × 20` |
| 3 | 01:42 | بیست بار از یک نفر | `20 answers from one question ≠ 20 questions  ·  198 questions: K=1 → 13.2% · K=10 → 7.5% · K=∞ → 6.6%` |
| 4 | 02:51 | ارزیابی یعنی آزمایش | `"Fundamentally, evaluations are experiments."  — Evan Miller, Anthropic · arXiv 2411.00640 · Nov 2024` |
| 5 | 03:42 | فقط اختلاف‌ها را بشمار | `Same 500 questions · unpaired MDE 8.0 pts → paired MDE 4.0 pts` |
| 6 | 04:47 | حدس بزن | `500 questions · true gap 2 pts · models agree on 90% → chance to detect it?  Paper ≈ 25% · our simulation 24%` |
| 7 | 05:51 | توان، MDE و هزارِ عنوان | `Power = chance to see a real gap  ·  MDE = smallest gap seen 80% of the time  ·  3-pt gap → ~969 questions` |
| 8 | 06:50 | اجرای منصفانه | `Run card: model + version + date · prompt · settings · tools · answer budget · retries · failure rule` |
| 9 | 07:47 | هزار سؤالِ چی؟ | `DROP, same data: clustered SE 1.34 vs naive 0.44 → ×3.05` |
| 10 | 08:47 | سه شکلِ هزار ردیف | `No real difference. Naive "winner": 1000×1 4.7% · 250×4 23.1% · 50×20 52.8%  ·  clustered ≈ 5% for all` |
| 11 | 10:09 | Bluff چند سؤال دارد؟ | `Bluff plan: 650 prompts → ≤ 450 base clusters · score −3…+1 · MDE 0.13 (SD 1) or 0.26 (SD 2) points per prompt` |
| 12 | 11:10 | قبل از نگاه کردن قفل کن | `6 models = 15 pairs → P(≥1 false "winner") ≈ 54%  ·  Lock first: primary comparison · practical gap · N & clusters · test · failure rule` |
| 13 | 12:14 | مرز ادعا | `THIS SHOWS / THIS DOES NOT SHOW` |
| 14 | 12:53 | جواب | `1,000 tries ≠ 1,000 pieces of evidence. Ask: independent questions? paired? smallest gap it could see?` |
| 15 | 13:45 | قسمت بعد | `Next: "This text was written by AI." How much text before you can say that?` |

## باز پیش از ضبط

- [ ] خوانش آزمایشی با زمان‌سنج؛ `data-start` دک و فصل‌های `package-fa.md` با زمان واقعی تنظیم شوند.
- [ ] هیچ نام مدل تجاری کنار عددهای شبیه‌سازی نیاید؛ Bluff «اجراشده» معرفی نشود.
- [ ] دک: ←/→، F، H، N امتحان شد.

## دستورهای روی صفحه (از README)

```bash
python3 parts/02-benchmarking/e06-how-many-questions-and-a-fair-run/artifact/power_lab.py             # seed 12 (عددهای متن، حدود ۵ ثانیه)
python3 parts/02-benchmarking/e06-how-many-questions-and-a-fair-run/artifact/power_lab.py --seed 11   # پایداری
python3 parts/02-benchmarking/e06-how-many-questions-and-a-fair-run/artifact/power_lab.py --icc 0.2   # همبستگی درون‌گروهی دیگر
python3 parts/02-benchmarking/e06-how-many-questions-and-a-fair-run/artifact/power_lab.py --selftest
python3 tools/bluff_lab.py plan --sd 1 --n 450 --delta 0.10                                            # قاب ۱۱
python3 tools/bluff_lab.py plan --sd 2 --n 450 --delta 0.10
python3 scripts/check-season-01.py                                                                     # HMD-012 ok
```

## B-roll

- قاب 1 (00:00): [B-ROLL CUE] دو جدول بلند کنار هم که از پایین صفحه بالا می‌آیند؛ هر دو یک سطر کهربایی دارند: `A − B = +3 pts`. هیچ نشانی از اینکه کدام چیست. برچسب گوشه: `ILLUSTRATIVE`. کات روی «من محمدم…».
- قاب 4 (02:51): [B-ROLL CUE] اسکرول آرام روی صفحهٔ اول مقاله در arXiv؛ بعد کارت منبع با نقل چهارواژه‌ای. سه توصیه از پنج توصیهٔ مقاله یکی‌یکی روشن می‌شوند: `paired differences` · `clustered standard errors` · `power analysis`.
- قاب 8 (06:50): [B-ROLL CUE] کارت اجرا (`artifact/fair-run-card.md`) که برای مدل A و B کنار هم پر می‌شود؛ یک خانه (`retries: 3` در برابر `retries: 1`) کهربایی می‌شود. هیچ نام مدل تجاری.
- قاب 10 (08:47): [CAMERA CHANGE] جملهٔ re-hook رو به دوربین؛ بعد [B-ROLL CUE] ضبط ترمینال `python3 artifact/power_lab.py` بخش ۴؛ سه ردیف یکی‌یکی ظاهر می‌شوند. پیش از ردیف سوم مکث ۲ ثانیه. [SOUND EFFECT] صدای سکه روی «مثل سکه انداختن». برچسب ثابت `ILLUSTRATIVE · ICC 0.5 assumed · seed 12`.
- قاب 15 (13:45): [SOUND EFFECT] صدای کوتاه تایپ؛ [B-ROLL CUE] یک پاراگراف که زیرش برچسب `AI-generated?` ظاهر و بعد کم‌رنگ می‌شود. End screen به HMD-013.

ساخته‌شده با `python3 scripts/export-teleprompter.py`. متن اصلی همیشه `script-fa.md` است.
