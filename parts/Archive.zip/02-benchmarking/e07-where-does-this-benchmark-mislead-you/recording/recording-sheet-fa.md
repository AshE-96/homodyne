# برگهٔ ضبط · HMD-014 · این جدول درست است؛ چرا گمراه‌کننده است؟

- **قاب:** 15 · **واژهٔ گفتاری:** 1721 · **گفتار:** حدود 13 دقیقه (به‌اضافهٔ زمان نمایش دک)
- **هوک:** Shock/Contradiction
- **دک:** [`deck-fa.html`](../deck-fa.html) (→ بعدی، ← قبلی، F تمام‌صفحه، H پنهان‌کردن نوار، N یادداشت راوی؛ هنگام ضبط H بزن و N خاموش باشد). قاب اول کاور است: بعد از هوک و معرفی کانال نشانش بده. نسخهٔ انگلیسی با همان ترتیب: [`deck-en.html`](../deck-en.html)
- **تله‌پرامپتر:** [`teleprompter-fa.html`](teleprompter-fa.html) (Space پخش/توقف، ↑↓ سرعت، M آینه) یا [`teleprompter-fa.txt`](teleprompter-fa.txt)

## نقشهٔ قاب‌ها

| قاب | شروع | عنوان | روی صفحه |
|---:|---|---|---|
| 1 | 00:00 | یک جدول، هر برنده‌ای که بخواهی | `Every number in this table is correct. Pick a winner.` |
| 2 | 00:49 | کدام بهتر است؟ حدس بزن | `Accuracy on answered: A 81.2% · B 90.5% → who is better?` |
| 3 | 01:53 | مخرج‌ها یکی نیستند | `Hard questions answered: A 390 / 400 · B 60 / 400` |
| 4 | 02:55 | برکلی، پاییز ۱۹۷۳ | `Berkeley, fall 1973: men 44% admitted · women 35%` |
| 5 | 04:03 | کدام عدد؟ | `Correct out of ALL 1,000: A 80.4% · B 58.8%` |
| 6 | 05:10 | کدام جریمه؟ | `Penalty k: k = 1 → A wins · k = 3 → B wins · flip at k = 1.74` |
| 7 | 06:18 | ده نسخه، یک انتشار | `10 private variants · true skill 70% each · published: 74.5%` |
| 8 | 07:29 | توهم جدول رتبه‌بندی | `27 private variants tested by Meta before Llama 4 · Singh et al., 2025` |
| 9 | 08:39 | holdout: آزمون کنارگذاشته | `Holdout, one run: 74.5% → 74.0%. Did the check fail?` |
| 10 | 09:50 | آلودگی و GSM1k | `GSM1k: 1,205 new problems · drops of up to 8% vs GSM8k` |
| 11 | 11:03 | نامعلوم را سبز نکن | `0 errors in 20 checked → could still be up to 16% → UNKNOWN` |
| 12 | 12:09 | سه سؤال جلوی هر جدول | `Which subset? · Which metric? · What wasn't shown?` |
| 13 | 13:18 | مرز ادعا | `THIS SHOWS / THIS DOES NOT SHOW` |
| 14 | 14:02 | جواب | `A correct table answers one chosen question. Ask which one.` |
| 15 | 14:56 | قسمت بعد | `The answer is in the file. Why does the AI still miss it?` |

## باز پیش از ضبط

- [ ] اگر پیش از ضبط LMArena یا نویسندگان نسخهٔ تازه‌ای منتشر کردند، قاب ۸ دوباره چک شود.
- [ ] هیچ عدد A/B به یک مدل واقعی نسبت داده نشده؛ Bluff اجراشده معرفی نشده.
- [ ] خوانش آزمایشی: اگر کل زمان از ۱۶ دقیقه گذشت، اول قاب ۴ (جملهٔ «حتی یه سوگیری کوچیک…») و قاب ۱۰ (جملهٔ آخر) کوتاه شوند.
- [ ] دک: ←/→، F، H، N امتحان شد.

## دستورهای روی صفحه (از README)

```bash
python3 parts/02-benchmarking/e07-where-does-this-benchmark-mislead-you/artifact/mislead_lab.py --selftest
python3 parts/02-benchmarking/e07-where-does-this-benchmark-mislead-you/artifact/mislead_lab.py            # seed 7 (عددهای متن)
python3 parts/02-benchmarking/e07-where-does-this-benchmark-mislead-you/artifact/mislead_lab.py --seed 11  # پایداری
python3 tools/bluff_lab.py score tools/bluff-demo.csv --condition t75 --max-fabrication 0.05            # "status": "UNKNOWN" در قاب ۱۱
```

## B-roll

- قاب 4 (02:55): [B-ROLL CUE] نمای عمومی و بی‌نام از یک پردیس دانشگاهی و برگه‌های درخواست بازسازی‌شده (بدون سند واقعی). بعد [UNEXPECTED STAT] کارت منبع: `Bickel, Hammel & O'Connell · Science 187 (1975) 398–404`؛ عدد ۴۴٪ و ۳۵٪، سپس دو پیکان «رشتهٔ سخت / رشتهٔ آسان».
- قاب 7 (06:18): [B-ROLL CUE] ضبط ترمینال `python3 artifact/mislead_lab.py` بخش ۴؛ ده عدد خصوصی کم‌رنگ، فقط `74.5` روشن و کهربایی. پیش از نمایش، مکث برای حدس. برچسب ثابت `ILLUSTRATIVE · simulated variants, seed 7`.
- قاب 12 (12:09): [B-ROLL CUE] یک جدول رتبه‌بندی ساختگی و بی‌برند روی لپ‌تاپ؛ سه برچسب روی آن می‌چسبد. کارت کوچک R11: `BetterBench · 24 benchmarks · 46 criteria`.
- قاب 15 (14:56): [SOUND EFFECT] صدای ورق‌خوردن؛ [B-ROLL CUE] یک سند ساختگی که یک بندش کهربایی است و یک پنجرهٔ چت کنارش. End screen به HMD-015.

ساخته‌شده با `python3 scripts/export-teleprompter.py`. متن اصلی همیشه `script-fa.md` است.
