# برگهٔ ضبط · HMD-018 · این نمرهٔ AI از کجا آمده؟ خودت بررسی کن

- **قاب:** 16 · **واژهٔ گفتاری:** 1644 · **گفتار:** حدود 13 دقیقه (به‌اضافهٔ زمان نمایش دک)
- **هوک:** Problem-Agitation
- **دک:** [`deck-fa.html`](../deck-fa.html) (→ بعدی، ← قبلی، F تمام‌صفحه، H پنهان‌کردن نوار، N یادداشت راوی؛ هنگام ضبط H بزن و N خاموش باشد). قاب اول کاور است: بعد از هوک و معرفی کانال نشانش بده. نسخهٔ انگلیسی با همان ترتیب: [`deck-en.html`](../deck-en.html)
- **تله‌پرامپتر:** [`teleprompter-fa.html`](teleprompter-fa.html) (Space پخش/توقف، ↑↓ سرعت، M آینه) یا [`teleprompter-fa.txt`](teleprompter-fa.txt)

## نقشهٔ قاب‌ها

| قاب | شروع | عنوان | روی صفحه |
|---:|---|---|---|
| 1 | 00:00 | «خودشون گفتن» | `"This model ranked #1." — Says who? Where are the files?` |
| 2 | 00:46 | از یوتیوب تا نمره | `Last time: why did YouTube suggest this video? Today: where did this score come from?` |
| 3 | 01:39 | منبع: چک‌لیست NeurIPS | `NeurIPS 2026 Paper Checklist: "code, data, and instructions needed to reproduce" · no checklist = desk reject` |
| 4 | 02:29 | فاکتور رستوران | `RECOMPUTE: same answers + same code → same number · RERUN: ask the model again → answers may change` |
| 5 | 03:28 | چهار فایل | `results.csv · METHOD.md · scorer code · CHANGELOG.md   (+ one more file)` |
| 6 | 04:24 | اثرانگشت فایل | `results.csv  35ceaaf4…  →  one label changed  →  0fb34f0c…` |
| 7 | 05:21 | قفل کن، بعداً نشان بده | `Held-out questions: publish the hash today, the questions later · personal data · licences` |
| 8 | 06:08 | بستهٔ سالم | `$ python3 artifact/recompute_check.py bundle --anchor e6db5cb8…  →  RESULT: PASS · A −0.100 · B +0.100` |
| 9 | 07:09 | دو دستکاری | `Tamper 1: one label → FAIL (results.csv hash) · Tamper 2: + new manifest → FAIL (A: published −0.100, recomputed +0.300)` |
| 10 | 08:09 | تقلب تمیز | `Tamper 3: label + published score + manifest, all rewritten → PASS (no anchor)` |
| 11 | 09:00 | لنگر | `Anchor = SHA-256 of the manifest, published OUTSIDE the bundle, with a date → Tamper 3: FAIL` |
| 12 | 09:42 | همان ویرایش، علنی | `Same edit, in public: v0.1 → v0.2 · CHANGELOG: item, reason, effect · new anchor NEXT TO the old one → PASS` |
| 13 | 10:46 | بنچمارکی که کنار گذاشته شد | `SWE-bench Verified · OpenAI, 23 Feb 2026: no longer reported · 138 hard problems audited · 59.4% with material issues` |
| 14 | 11:38 | مرز ادعا | `THIS SHOWS / THIS DOES NOT SHOW` |
| 15 | 12:19 | جواب، و کل دوره | `4 files + 1 anchor = a score anyone can recompute` |
| 16 | 13:35 | قسمت بعد | `Next: we gave the paper to an AI. Can it repeat the experiment?` |

## باز پیش از ضبط

- [ ] هیچ نتیجهٔ Bluff واقعی در این قسمت ادعا نشده؛ اگر نتیجهٔ E08 منتشر شده، فقط با لنگر و لینک واقعی آن به آن اشاره کن.
- [ ] لنگر واقعی بستهٔ این قسمت روز انتشار در توضیحات، کامنت پین‌شده و تاریخچهٔ گیت گذاشته شد (URL ساختگی ممنوع).
- [ ] دک: ←/→، F، H، N امتحان شد.

## دستورهای روی صفحه (از README)

```bash
A=parts/02-benchmarking/e09-how-do-you-publish-a-refutable-result/artifact
python3 $A/recompute_check.py --selftest                           # پنج بسته، هر کدام بی‌لنگر و با لنگر
python3 $A/recompute_check.py --demo /tmp/b                         # بستهٔ آموزشی v0.1 + چاپ لنگر
python3 $A/recompute_check.py /tmp/b --anchor <sha256>              # PASS
python3 $A/recompute_check.py --demo /tmp/t --variant tamper-all    # تقلب تمیز
python3 $A/recompute_check.py /tmp/t                                # PASS بدون لنگر (!)
python3 $A/recompute_check.py /tmp/t --anchor <لنگر v0.1>           # FAIL
python3 $A/recompute_check.py /tmp/b --claim A=0.3                  # عددی که روی اسکرین‌شات دیدی
```
```bash
# ILLUSTRATIVE (teaching bundle; no model was called)
# selftest: one original bundle, three tampered ones, one public correction
# every bundle is checked twice: without and with the anchor published outside it

anchor v0.1 = sha256(MANIFEST.sha256) = e6db5cb88679bd980353f1188a716a1a34b6d07eb03f3ccc2e6206677eb0ad2b

[original           ] no anchor   -> PASS
[original           ] anchor e6db5cb8 -> PASS
  ok    manifest matches the published anchor e6db5cb88679...
  ok    results.csv     35ceaaf427d7...
  ok    published.json  9f7fb21f0017...
  ok    METHOD.md       53c632aa8884...
  ok    CHANGELOG.md    833d23ee3f61...
  ok    version v0.1 is the newest of 1 log entry
  ok    A: published -0.100 == recomputed -0.100
  ok    B: published +0.100 == recomputed +0.100

[tamper-csv         ] no anchor   -> FAIL  first mismatch: hash mismatch in results.csv: manifest 35ceaaf427d7..., file 0fb34f0c362b...
[tamper-csv         ] anchor e6db5cb8 -> FAIL  first mismatch: hash mismatch in results.csv: manifest 35ceaaf427d7..., file 0fb34f0c362b...

[tamper-csv-manifest] no anchor   -> FAIL  first mismatch: score of A: published -0.100, recomputed +0.300
[tamper-csv-manifest] anchor e6db5cb8 -> FAIL  first mismatch: manifest anchor: published e6db5cb88679..., bundle has 55734e42755b...

[tamper-all         ] no anchor   -> PASS
[tamper-all         ] anchor e6db5cb8 -> FAIL  first mismatch: manifest anchor: published e6db5cb88679..., bundle has 3013a118e3d7...

[correction         ] no anchor   -> PASS
[correction         ] anchor 57772828 -> PASS
  ok    manifest matches the published anchor 577728283b70...
  ok    results.csv     0fb34f0c362b...
  ok    published.json  93e133b7daa7...
  ok    METHOD.md       53c632aa8884...
  ok    CHANGELOG.md    9659319087d5...
  ok    version v0.2 is the newest of 2 log entries
  ok    A: published +0.300 == recomputed +0.300
  ok    B: published +0.100 == recomputed +0.100

[original, viewer types A=+0.300 from a screenshot] -> FAIL  first mismatch: score of A: claimed +0.300, recomputed -0.100

selftest: all expectations met
```

## B-roll

- قاب 1 (00:00): [B-ROLL CUE] اسکرین‌شات ساختگی (بدون نام مدل یا شرکت واقعی) که در چند چت فوروارد می‌شود؛ شمارندهٔ فوروارد بالا می‌رود؛ برچسب کوچک `ILLUSTRATIVE screenshot`. روی «خودشون گفتن» فریز. کات روی «من محمدم…».
- قاب 4 (02:29): [B-ROLL CUE] فاکتور رستوران و ماشین‌حساب گوشی؛ بعد بشقاب غذا در روز دیگر. سپس دو ستون روی دک: `RECOMPUTE` (کهربایی) و `RERUN`.
- قاب 7 (05:21): [B-ROLL CUE] پاکت مهروموم‌شده با برچسب تاریخ؛ روی پاکت فقط رشتهٔ هش. بعد سه برچسب: `held-out` · `personal data` · `no licence to republish`؛ `held-out` کهربایی.
- قاب 8 (06:08): [B-ROLL CUE] ضبط ترمینال از `recompute_check.py --selftest` (بخش `original`)؛ سطرهای `ok` یکی‌یکی؛ `PASS` کهربایی. برچسب ثابت `ILLUSTRATIVE · course teaching file · no model was called`.
- قاب 16 (13:35): [SOUND EFFECT] صدای کوتاه کاغذ؛ [B-ROLL CUE] صفحهٔ اول یک مقاله (بدون عنوان خوانا) که داخل یک پنجرهٔ چت کشیده می‌شود. End screen به HMD-019.

ساخته‌شده با `python3 scripts/export-teleprompter.py`. متن اصلی همیشه `script-fa.md` است.
