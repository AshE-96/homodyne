# برگهٔ ضبط · HMD-010 · نمرهٔ منفی می‌تواند AI را محتاط‌تر کند؟

- **قاب:** 15 · **واژهٔ گفتاری:** 1664 · **گفتار:** حدود 13 دقیقه (به‌اضافهٔ زمان نمایش دک)
- **هوک:** Story-Open کنکور
- **دک:** [`deck-fa.html`](../deck-fa.html) (→ بعدی، ← قبلی، F تمام‌صفحه، H پنهان‌کردن نوار، N یادداشت راوی؛ هنگام ضبط H بزن و N خاموش باشد). قاب اول کاور است: بعد از هوک و معرفی کانال نشانش بده. نسخهٔ انگلیسی با همان ترتیب: [`deck-en.html`](../deck-en.html)
- **تله‌پرامپتر:** [`teleprompter-fa.html`](teleprompter-fa.html) (Space پخش/توقف، ↑↓ سرعت، M آینه) یا [`teleprompter-fa.txt`](teleprompter-fa.txt)

## نقشهٔ قاب‌ها

| قاب | شروع | عنوان | روی صفحه |
|---:|---|---|---|
| 1 | 00:00 | سؤال ۱۳۷ | `Question 137. Two options left. Answer or skip?` |
| 2 | 00:47 | قانون کنکور | `Right +3 · Wrong −1 · Blank 0 → a blind guess is worth … ?` |
| 3 | 01:36 | صفر، یک‌نهم، یک‌سوم | `4 options: 0 · 3 options: +1/9 · 2 options: +1/3 (of one right answer)` |
| 4 | 02:39 | خط سکوت | `Answer only if P(correct) > t = k/(k+1)` |
| 5 | 03:38 | چرا AI حدس می‌زند | `Most AI tests: Right +1 · Wrong 0 · "I don't know" 0` |
| 6 | 04:52 | یک غلط در خود مقاله | `Paper: "t = 0.75 (penalty 2)" · Formula t/(1−t): 0.75/0.25 = 3` |
| 7 | 05:56 | نمره‌دادن دوباره ≠ رفتار تازه | `Rescoring changes the number. Instructing might change the answers.` |
| 8 | 07:04 | پاسخ‌دهندهٔ صادق | `Calibrated answerer, k = 3: always answer −0.79 · answer only above 75% +0.13` |
| 9 | 08:24 | بیش‌ازحد مطمئن | `Overconfident answerer, k = 3: answers 59% · wrong 27% of answers · score −0.05` |
| 10 | 09:28 | سؤال واقعی | `Same questions · 4 prompts: plain · t50 · t75 · t90 · fresh answers` |
| 11 | 10:33 | آزمایشی که هنوز اجرا نشده | `NOT RUN YET · plain vs t50 vs t75 vs t90 — three possible outcomes` |
| 12 | 11:20 | k را چه کسی تعیین می‌کند؟ | `Trivia: k small · Store policy: k larger · There is no universal k` |
| 13 | 12:18 | مرز ادعا | `THIS SHOWS / THIS DOES NOT SHOW` |
| 14 | 12:56 | جواب | `On paper: yes. In practice: only if the model listens and its confidence is honest.` |
| 15 | 13:49 | قسمت بعد | `Not "rain" or "I don't know" — "70% chance of rain".` |

## باز پیش از ضبط

- [ ] `python3 artifact/penalty_threshold.py` اجرا و با قاب ۳، ۴، ۸، ۹ و دک تطبیق داده شد (seed 5: k=3 calibrated 0.130 / 29% / 14%؛ overconfident −0.054 / 59% / 27%؛ always-answer −0.792).
- [ ] جملهٔ قاب ۶ با متن نسخهٔ فعلی arXiv دوباره چک شد (اگر نسخهٔ جدید «penalty 3» را اصلاح کرده، بگو «نسخهٔ اول» و تاریخ را روی صفحه بیاور).
- [ ] هیچ نتیجهٔ اجرانشده‌ای به یک مدل تجاری نسبت داده نشده؛ Bluff اجراشده معرفی نشده.
- [ ] دک: ←/→، F، H، N امتحان شد.

## دستورهای روی صفحه (از README)

```bash
python3 parts/02-benchmarking/e05-how-do-you-penalise-a-bluff/artifact/penalty_threshold.py           # seed 5 (عددهای متن)
python3 parts/02-benchmarking/e05-how-do-you-penalise-a-bluff/artifact/penalty_threshold.py --seed 11 # پایداری
python3 tools/bluff_lab.py score tools/bluff-demo.csv --condition t75                                  # plain_note در قاب ۷
```

## B-roll

- قاب 1 (00:00): [B-ROLL CUE] نمای خیلی نزدیک از پاسخ‌برگ چهارگزینه‌ای بازسازی‌شده؛ دو گزینه خط‌خورده، مداد بالای دو گزینهٔ دیگر می‌لرزد؛ صدای تیک‌تاک ساعت. بدون لوگو یا سند واقعی. کات روی «من محمدم…».
- قاب 8 (07:04): [B-ROLL CUE] ضبط صفحه از اجرای `python3 artifact/penalty_threshold.py`؛ بخش ۴. برچسب ثابت `ILLUSTRATIVE · simulated answerers, not language models`.
- قاب 12 (11:20): [B-ROLL CUE] سه تصویر کوتاه: بازی حدس اسم فیلم با دوستان، رسید خرید و قانون مرجوعی، و (فقط نماد) یک داروخانهٔ عمومی بدون توصیهٔ پزشکی. کارت کوچک: `AA-Omniscience (R08): score 0 = as many right as wrong → k = 1`.
- قاب 15 (13:49): [SOUND EFFECT] صدای کوتاه باران؛ [B-ROLL CUE] آسمان ابری و صفحهٔ یک اپ هواشناسی عمومی با `70%`. End screen به HMD-011.

ساخته‌شده با `python3 scripts/export-teleprompter.py`. متن اصلی همیشه `script-fa.md` است.
