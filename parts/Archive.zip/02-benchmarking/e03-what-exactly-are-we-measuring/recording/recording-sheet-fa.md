# برگهٔ ضبط · HMD-006 · وقتی می‌گویند AI کمتر خطا می‌کند، چه چیزی را نمی‌گویند؟

- **قاب:** 14 · **واژهٔ گفتاری:** 1546 · **گفتار:** حدود 12 دقیقه (به‌اضافهٔ زمان نمایش دک)
- **هوک:** Shock/Contradiction
- **دک:** [`deck-fa.html`](../deck-fa.html) (→ بعدی، ← قبلی، F تمام‌صفحه، H پنهان‌کردن نوار، N یادداشت راوی؛ هنگام ضبط H بزن و N خاموش باشد). قاب اول کاور است: بعد از هوک و معرفی کانال نشانش بده. نسخهٔ انگلیسی با همان ترتیب: [`deck-en.html`](../deck-en.html)
- **تله‌پرامپتر:** [`teleprompter-fa.html`](teleprompter-fa.html) (Space پخش/توقف، ↑↓ سرعت، M آینه) یا [`teleprompter-fa.txt`](teleprompter-fa.txt)

## نقشهٔ قاب‌ها

| قاب | شروع | عنوان | روی صفحه |
|---:|---|---|---|
| 1 | 00:00 | کم‌خطاترین دستیار دنیا | `0% errors. 0% useful.` |
| 2 | 00:45 | سه نوع جواب | `Every answer is one of three: correct · wrong · "I don't know"` |
| 3 | 01:40 | ده کارت | `10 answers: 5 correct · 2 wrong · 3 "I don't know"` |
| 4 | 02:40 | یک دسته کارت، سه عدد درست | `2/10 = 20% · 2/7 ≈ 29% · 2/5 = 40%` |
| 5 | 03:40 | جدول واقعی و ستونی که دیده نمی‌شود | `SimpleQA · error rate: 26% vs 75%` |
| 6 | 04:45 | همان جدول، با مخرج دیگر | `When it does answer: 26/48 ≈ 54% vs 75/99 ≈ 76% wrong` |
| 7 | 05:50 | چهار عدد کنار هم | `Accuracy · Coverage · Risk · Score` |
| 8 | 06:55 | دستیار ساکت و خط سکوت | `Always "I don't know": risk = undefined · score = 0` |
| 9 | 07:50 | هوک دوم: ۱٫۸٪ یا ۸۱٪؟ | `"Hallucination rate": 1.8% … 81%` |
| 10 | 08:55 | چیزی که می‌خواهیم، چیزی که می‌شماریم | `What we want ≠ what we count` |
| 11 | 09:55 | کارت سازه | `Construct card: want · count · formula · misses` |
| 12 | 10:55 | مرز ادعا | `THIS SHOWS / THIS DOES NOT SHOW` |
| 13 | 11:40 | جواب | `Out of what? · Bought with what?` |
| 14 | 12:20 | قسمت بعد | `Next: what if the document itself is steering the AI?` |

## باز پیش از ضبط

- [ ] جدول زندهٔ Vectara را روز ضبط ببین (آخرین بازبینی: به‌روزرسانی ۲۲ اکتبر ۲۰۲۶، کمترین ۱٫۸٪).
- [ ] اجرای `bluff_lab` و تطبیق A = −0.1 و B = +0.1 با دک.
- [ ] خوانش آزمایشی و تنظیم `data-start` دک.
- [ ] جدول Vectara را روز ضبط دوباره ببین؛ اگر کمترین عدد عوض شده، عدد و تاریخ را در قاب ۹، دک و توضیحات عوض کن.
- [ ] `python3 tools/bluff_lab.py score tools/bluff-demo.csv --condition t75` را اجرا کن؛ باید A = −0.1 و B = +0.1 باشد.
- [ ] هیچ‌جا نگو Bluff اجرا شده یا نتیجه دارد.
- [ ] نام مدل‌ها دقیقاً مثل منبع: «gpt-5-thinking-mini» و «o4-mini» در R01؛ «GPT-5 (high)» در AA-Omniscience.
- [ ] دک: ۱۴ قاب؛ کلیدها، F، H و N.

## B-roll

- قاب 2 (00:45): [B-ROLL CUE] اسکرول یک فید خبری ساختگی با تیترهای «مدل جدید سه برابر کمتر توهم می‌زند». بعد سه کارت بزرگ: درست، غلط، نمی‌دانم.
- قاب 7 (05:50): [B-ROLL CUE] ضبط صفحه: `python3 tools/bluff_lab.py score tools/bluff-demo.csv --condition t75`. خروجی واقعی برای مدل‌های آموزشی A و B. برچسب ILLUSTRATIVE.
- قاب 11 (09:55): [B-ROLL CUE] باز کردن `artifact/construct-card.md`؛ پرکردن چهار خط برای جملهٔ «مدل جدید کمتر خطا می‌کند» روی صفحه.

ساخته‌شده با `python3 scripts/export-teleprompter.py`. متن اصلی همیشه `script-fa.md` است.
