# برگهٔ ضبط · HMD-G01 · وقتی AI از نوشته‌های AI یاد بگیرد چه می‌شود؟

- **قاب:** 14 · **واژهٔ گفتاری:** 1554 · **گفتار:** حدود 12 دقیقه (به‌اضافهٔ زمان نمایش دک)
- **هوک:** Shock/Contradiction
- **دک:** [`deck-fa.html`](../deck-fa.html) (→ بعدی، ← قبلی، F تمام‌صفحه، H پنهان‌کردن نوار، N یادداشت راوی؛ هنگام ضبط H بزن و N خاموش باشد). قاب اول کاور است: بعد از هوک و معرفی کانال نشانش بده. نسخهٔ انگلیسی با همان ترتیب: [`deck-en.html`](../deck-en.html)
- **تله‌پرامپتر:** [`teleprompter-fa.html`](teleprompter-fa.html) (Space پخش/توقف، ↑↓ سرعت، M آینه) یا [`teleprompter-fa.txt`](teleprompter-fa.txt)

## نقشهٔ قاب‌ها

| قاب | شروع | عنوان | روی صفحه |
|---:|---|---|---|
| 1 | 00:00 | نصف وب را ماشین می‌نویسد | `Half the new web is machine-written. The next model learns from it.` |
| 2 | 00:45 | کپیِ کپی | `A copy of a copy of a copy.` |
| 3 | 01:45 | چقدر از وب ماشینی است؟ | `~50% of new English articles: primarily AI-written (detector estimate)` |
| 4 | 02:45 | دیوار داده | `Public human text: ~300 trillion tokens. Fully used: 2026–2032 (80% CI).` |
| 5 | 03:40 | منبع اصلی | `Shumailov et al. · Nature · July 2024` |
| 6 | 04:35 | کوچک‌ترین مدل دنیا | `Fit → sample → fit → sample … (n = 100 per generation)` |
| 7 | 05:35 | دنباله‌ها اول می‌میرند | `Generation 100: width 0.37 · rare tail 4.7% → 0.00%` |
| 8 | 06:40 | واژه‌ها و رانش ژنتیکی | `3,172 words → 2,550 (gen 1) → 1,076 (gen 10) → 220 (gen 100)` |
| 9 | 07:50 | هوک دوم: دادهٔ آدم را دور نمی‌ریزند | `Replace: collapse. Keep 10% real: holds. Accumulate: holds.` |
| 10 | 08:55 | خطر واقعی: باریک‌شدن آرام | `Keep 10% real: 1,774 words survive. Rare half: 573 of 1,586.` |
| 11 | 10:00 | فولاد پیش از بمب | `Low-background steel: made before 1945. Human data: made before 2022?` |
| 12 | 10:55 | مرز ادعا | `THIS SHOWS / THIS DOES NOT SHOW` |
| 13 | 11:40 | جواب | `Replace → collapse. Accumulate → survive.` |
| 14 | 12:35 | قسمت بعد | `Next: a lock everyone uses — and a key someone is building.` |

## باز پیش از ضبط

- [ ] اجرای دوبارهٔ `collapse_lab.py` (کامل، نه `--quick`) و تطبیق با `results-seed2026.md`. **روی دوربین `--quick` اجرا نشود**: عددهایش (۲۱۷، ۳۲۲۹) با متن (۲۲۰، ۳۱۷۲) فرق دارد.
- [ ] ساخت انیمیشن منحنی از `results-seed2026.json` (یادداشت تدوین در `script-fa.md`).
- [ ] ثبت پیش‌بینی قاب ۱۳ در دفتر پیش‌بینی هومودین در روز انتشار.
- [ ] `python3 artifact/collapse_lab.py` را دوباره اجرا کن (حدود ۹۰ ثانیه) و با `artifact/results-seed2026.md` تطبیق بده.
- [ ] جملهٔ «روی سه نوع مدل آزمایش کردند» را با مقالهٔ Nature تطبیق بده (Gaussian mixture، VAE، مدل زبانی OPT-125m).
- [ ] هیچ مدل یا شرکت مشخصی «فروریخته» نامیده نشود.
- [ ] پیش‌بینی قاب ۱۳ همان روز انتشار در دفتر پیش‌بینی ثبت شود: تاریخ، احتمال و معیار ابطال.
- [ ] دک: کلیدها، F، H و N؛ تعداد قاب‌ها ۱۴.

## دستورهای روی صفحه (از README)

```bash
python3 parts/04-global/hmd-g01-model-collapse/artifact/collapse_lab.py            # حدود ۹۰ ثانیه؛ results-seed2026.md/json را می‌نویسد
python3 parts/04-global/hmd-g01-model-collapse/artifact/collapse_lab.py --quick    # برای دموی زنده، حدود ۱۵ ثانیه، چیزی نمی‌نویسد
python3 parts/04-global/hmd-g01-model-collapse/artifact/collapse_lab.py --text my.txt   # آزمایش واژه روی متن خودت
```

## B-roll

- قاب 1 (00:00): [B-ROLL CUE] اسکرول سریع صفحه‌های وب. روی بعضی پاراگراف‌ها یک برچسب کوچک کهربایی `AI` ظاهر می‌شود، تقریباً روی نصفشان. بعد کات به نمودار زنگوله‌ای که نسل به نسل باریک می‌شود. قاب night.
- قاب 11 (10:00): [B-ROLL CUE] تصویر آرشیوی یک کشتی غرق‌شده و یک آشکارساز تابش در آزمایشگاه. بعد یک برچسب کهربایی روی یک فایل متنی: `pre-2022`.

ساخته‌شده با `python3 scripts/export-teleprompter.py`. متن اصلی همیشه `script-fa.md` است.
