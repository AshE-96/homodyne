# HMD-B07 · AI از یک عکس می‌فهمد کجایی؟

**قالب:** Benchmark Lab (پل: جهانی و ایرانی)
**سری:** ایدهٔ ۷ از [`idea-bank-bridge-fa.md`](../../../channel/season-01/idea-bank-bridge-fa.md)
**وضعیت:** نیازمند اجرا `[RUN]`. منبع‌ها خوانده و تأیید شده‌اند. متن، هوک‌ها، بستهٔ انتشار و دک آماده‌اند. نتیجهٔ آزمایش ۲۰ عکس جای خالی دارد.
**شناسه:** HMD-B07 موقت است. شمارهٔ نهایی HMD هنگام زمان‌بندی داده می‌شود.
**زمان برآوردی:** ۱۳ تا ۱۴ دقیقه · **واژهٔ گفتاری:** 1,652 · **قاب:** 15 · **قاب‌های دک:** 15

**جملهٔ مرکزی:** مدل‌های امروزی از سرنخ‌های معمولی یک عکس، جای عکاسی را اغلب تا حد شهر و گاهی تا حد خیابان پیدا می‌کنند، حتی وقتی متادیتا پاک شده باشد. پوشاندن سرنخ‌ها کمک می‌کند ولی کافی نیست.

**مرز ادعا:** ۲۰ عکس از یک نفر، دقت عمومی هیچ مدلی را نشان نمی‌دهد. عدد ۶۰٪ مقاله فقط مال عکس‌های آمریکایی و یک مدل است. ویدیو فقط با عکس‌های خود محمد کار می‌کند و هیچ‌کس را پیدا نمی‌کند.

## عددهای منتشرشده (تأییدشده، ۴ نوامبر ۲۰۲۶)

| ادعا | عدد | منبع |
|---|---|---|
| o3 روی ۵۰ عکس جلوی خانه‌های آمریکا | ۶۰٪ زیر ۱ مایل، ۸۴٪ زیر ۵ مایل | R-B01 |
| بهترین مدل‌ها روی ۵۲ عکس منتشرنشده | بیش از ۵۰٪ زیر ۲۵ کیلومتر | R-B02 |
| PIGEON در برابر بازیکن‌های GeoGuessr | بهتر از Champion Division؛ ۶ از ۶ در برابر حرفه‌ای؛ میانه ۴۴٫۴ کیلومتر | R-B03 |
| مدل‌های ۲۰۲۴ روی جاهای معروف ایران | ۱۶٫۴ تا ۱۷٫۱٪ | R-B05 |

## فایل‌ها

| فایل | چیست |
|---|---|
| [`script-fa.md`](script-fa.md) | متن ضبط v5، ۱۵ قاب، با دو شاخهٔ آماده برای نتیجه |
| [`hooks-fa.md`](hooks-fa.md) | پنج هوک و توصیه (برنده: Shock/Contradiction) |
| [`package-fa.md`](package-fa.md) | عنوان، تامبنیل A/B/C، توضیحات، فصل‌ها، تگ، کامنت، End screen، دو Short، Community، metadata انگلیسی |
| [`deck-fa.html`](deck-fa.html) | دک ضبط v6، فارسی و راست‌به‌چپ: کاور + ۱۵ قاب (→ ← · F · H · N) |
| [`deck-en.html`](deck-en.html) | همان دک به انگلیسی، با همان قاب‌ها و همان ترتیب |
| [`deck.src.html`](deck.src.html) | منبع دوزبانهٔ هر دو دک؛ بعد از ویرایش `make decks` |
| [`sources.md`](sources.md) | منابع R-B01 تا R-B06 |
| [`artifact/geo_lab.py`](artifact/geo_lab.py) | پاک‌کردن متادیتا، پرسش ثابت، و امتیازدهی (فقط کتابخانهٔ استاندارد Python) |

### اجرای فایل همراه

```bash
python3 parts/04-global/hmd-b07-photo-geolocation/artifact/geo_lab.py selftest
```

```bash
python3 parts/04-global/hmd-b07-photo-geolocation/artifact/geo_lab.py strip ~/Pictures/geo-iran --set iran
```

```bash
python3 parts/04-global/hmd-b07-photo-geolocation/artifact/geo_lab.py strip ~/Pictures/geo-abroad --set abroad
```

```bash
python3 parts/04-global/hmd-b07-photo-geolocation/artifact/geo_lab.py prompt
```

```bash
python3 parts/04-global/hmd-b07-photo-geolocation/artifact/geo_lab.py score
```

- خروجی در `private/geo-lab/` است که git آن را نادیده می‌گیرد.
- هر حدس یک سطر در `guesses.csv` می‌شود: `photo,model,mask,lat,lon`، با mask یکی از `L0` تا `L3` و model مثلاً `chatgpt`، `gemini`، `claude` یا `human`.
- عکس‌های HEIC آیفون را اول به JPEG تبدیل کن. با تنظیم Most Compatible، یا Export در Photos با «Include location» روشن.

## پیش از ضبط باید حل شود

- [ ] [RUN] ۲۰ عکس منتشرنشده، بدون آدم و دور از خانه: ۱۰ از ایران (چند شهر)، ۱۰ از خارج.
- [ ] [RUN] اجرای `strip` روی یک عکس واقعی آیفون یا اندروید: `truth.csv` مختصات درست بدهد و نسخهٔ تمیز در Preview موقعیتی نشان ندهد. EXIF خوان روی دادهٔ ساختگی آزموده شده، نه هنوز روی عکس واقعی.
- [ ] [RUN] حدس سه مدل و خود محمد برای L0. بعد برای L1 تا L3، دست‌کم روی ۱۰ عکس. تنظیم ابزارهای هر مدل (جست‌وجو روشن یا خاموش) ثبت شود.
- [ ] [RUN] اجرای `score`، پر کردن قاب ۹، ۱۰ و ۱۴ در متن و دک، و انتخاب شاخهٔ الف یا ب.
- [ ] [VERIFY] پوشش Google Street View در ایران (قاب ۱۱).
- [ ] تطبیق «بیش از نصف زیر ۲۵ کیلومتر» با جدول تعاملی Bellingcat.
- [ ] ثبت پیش‌بینی قاب ۱۴ در دفتر پیش‌بینی هومودین، با میانهٔ پایهٔ همان روز.

**زنجیره:** بعدی در ترتیب پل، «چند درصد علم را ChatGPT می‌نویسد؟» (ایدهٔ ۱۳). کارت میانی به [HMD-005](../../03-standalone/hmd-005-persian-tokens/README.md) (توکن فارسی) وصل است.
