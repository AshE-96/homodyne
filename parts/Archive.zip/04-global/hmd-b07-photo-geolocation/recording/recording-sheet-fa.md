# برگهٔ ضبط · HMD-B07 · AI از یک عکس می‌فهمد کجایی؟

- **قاب:** 15 · **واژهٔ گفتاری:** 1649 · **گفتار:** حدود 13 دقیقه (به‌اضافهٔ زمان نمایش دک)
- **هوک:** Shock/Contradiction
- **دک:** [`deck-fa.html`](../deck-fa.html) (→ بعدی، ← قبلی، F تمام‌صفحه، H پنهان‌کردن نوار، N یادداشت راوی؛ هنگام ضبط H بزن و N خاموش باشد). قاب اول کاور است: بعد از هوک و معرفی کانال نشانش بده. نسخهٔ انگلیسی با همان ترتیب: [`deck-en.html`](../deck-en.html)
- **تله‌پرامپتر:** [`teleprompter-fa.html`](teleprompter-fa.html) (Space پخش/توقف، ↑↓ سرعت، M آینه) یا [`teleprompter-fa.txt`](teleprompter-fa.txt)

## نقشهٔ قاب‌ها

| قاب | شروع | عنوان | روی صفحه |
|---:|---|---|---|
| 1 | 00:00 | ۶۰٪ زیر یک مایل | `60% of guesses: less than 1 mile away. No GPS.` |
| 2 | 00:45 | عکس بالکن | `What does one ordinary photo give away?` |
| 3 | 01:45 | دو آزمایش منتشرشده | `o3: 60% < 1 mile · 84% < 5 miles (50 US photos)` |
| 4 | 02:50 | متادیتا؛ و چرا مهم نیست | `EXIF: GPS 35.70, 51.40 → removed. The pixels still talk.` |
| 5 | 03:50 | قهرمان‌های GeoGuessr | `PIGEON: top 0.01% of GeoGuessr players · 6/6 vs a pro` |
| 6 | 04:55 | مدل چطور فکر می‌کند | `Pixels → embedding → nearest places → reasoning → one point` |
| 7 | 05:55 | معمای ایران | `Iran-Places: 16–17% (GPT-4o, Claude 3.5, Llama 3.2 · 2024)` |
| 8 | 07:00 | آزمایش من | `20 photos · EXIF removed · 3 models + 1 human · same prompt` |
| 9 | 08:00 | نتیجه | `[RUN] median error · Iran vs abroad · best model vs me` |
| 10 | 09:10 | پوشاندن سرنخ‌ها | `L0 original → L1 text hidden → L2 landmarks hidden → L3 tight crop` |
| 11 | 10:15 | چرا ایران | `More photos online → easier to place` |
| 12 | 11:15 | پنج قدم پیش از پست‌کردن | `1 location off · 2 strip metadata · 3 no street + home · 4 hide text · 5 post later` |
| 13 | 12:10 | مرز ادعا | `THIS SHOWS / THIS DOES NOT SHOW` |
| 14 | 12:50 | جواب | `Answer: often the city, sometimes the street.` |
| 15 | 13:35 | قسمت بعد | `Next: one word exposed how much of science ChatGPT writes.` |

## باز پیش از ضبط

- [ ] [RUN] ۲۰ عکس منتشرنشده، بدون آدم و دور از خانه: ۱۰ از ایران (چند شهر)، ۱۰ از خارج.
- [ ] [RUN] اجرای `strip` روی یک عکس واقعی آیفون یا اندروید: `truth.csv` مختصات درست بدهد و نسخهٔ تمیز در Preview موقعیتی نشان ندهد. EXIF خوان روی دادهٔ ساختگی آزموده شده، نه هنوز روی عکس واقعی.
- [ ] [RUN] حدس سه مدل و خود محمد برای L0. بعد برای L1 تا L3، دست‌کم روی ۱۰ عکس. تنظیم ابزارهای هر مدل (جست‌وجو روشن یا خاموش) ثبت شود.
- [ ] [RUN] اجرای `score`، پر کردن قاب ۹، ۱۰ و ۱۴ در متن و دک، و انتخاب شاخهٔ الف یا ب.
- [ ] [VERIFY] پوشش Google Street View در ایران (قاب ۱۱).
- [ ] تطبیق «بیش از نصف زیر ۲۵ کیلومتر» با جدول تعاملی Bellingcat.
- [ ] ثبت پیش‌بینی قاب ۱۴ در دفتر پیش‌بینی هومودین، با میانهٔ پایهٔ همان روز.
- [ ] [RUN] ۲۰ عکس، ۱۰ ایران و ۱۰ خارج: هیچ‌کدام قبلاً آنلاین نبوده، بدون آدم، و دور از خانه.
- [ ] [RUN] `python3 artifact/geo_lab.py strip <پوشهٔ ایران> --set iran` و `strip <پوشهٔ خارج> --set abroad`. خروجی در `private/geo-lab/` است که git آن را نادیده می‌گیرد.
- [ ] یکی از عکس‌های تمیز در Preview یا Photos باز شود تا معلوم شود موقعیتی نشان نمی‌دهد.
- [ ] [RUN] هر عکس تمیز به سه مدل با همان متن `geo_lab.py prompt` داده شود. ابزارها (جست‌وجو و نقشه) روشن یا خاموش بودنشان ثبت شود. حدس خود محمد هم با نام مدل `human` ثبت شود.
- [ ] [RUN] برای سطح‌های L1 تا L3 همان کار تکرار شود (دست‌کم روی ۱۰ عکس).
- [ ] [RUN] `python3 artifact/geo_lab.py score`، و عددها در قاب ۹، ۱۰ و ۱۴ پر شوند. فقط شاخهٔ درست قاب ۹ ضبط شود.
- [ ] [VERIFY] «Street View در ایران عملاً پوشش ندارد»: پیش از ضبط روی نقشهٔ پوشش Google Street View دیده شود.
- [ ] عددهای Bellingcat (بیش از نصف زیر ۲۵ کیلومتر) با جدول تعاملی خود صفحه تطبیق داده شوند.
- [ ] پیش‌بینی قاب ۱۴ روز انتشار در دفتر پیش‌بینی ثبت شود، با میانهٔ پایهٔ همان روز.
- [ ] دک: کلیدها، F، H و N؛ تعداد قاب‌ها ۱۵.

## دستورهای روی صفحه (از README)

```bash
python3 parts/04-global/hmd-b07-photo-geolocation/artifact/geo_lab.py selftest
```
```bash
python3 parts/04-global/hmd-b07-photo-geolocation/artifact/geo_lab.py strip ~/Pictures/geo-iran --set iran
```
```bash
python3 parts/04-global/hmd-b07-photo-geolocation/artifact/geo_lab.py strip ~/Pictures/geo-abroad --set abroad
```
```bash
python3 parts/04-global/hmd-b07-photo-geolocation/artifact/geo_lab.py prompt
```
```bash
python3 parts/04-global/hmd-b07-photo-geolocation/artifact/geo_lab.py score
```

## B-roll

- قاب 1 (00:00): - [B-ROLL CUE] یک عکس معمولی از یک کوچه.
- قاب 5 (03:50): - [B-ROLL CUE] صفحهٔ بازی GeoGuessr.
- قاب 11 (10:15): - [B-ROLL CUE] نقشهٔ جهان با چگالی عکس‌های آنلاین: جاهایی پرنور، جاهایی تاریک.

ساخته‌شده با `python3 scripts/export-teleprompter.py`. متن اصلی همیشه `script-fa.md` است.
